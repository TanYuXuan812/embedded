#ifndef IR_SENSOR_H
#define IR_SENSOR_H

#include "pico/stdlib.h"

// IR Sensor pins
#define IR_ANALOG_PIN   28      // GPIO 28 = ADC2 for ANALOG contrast detection
#define IR_DIGITAL_PIN  7       // GPIO 7 for DIGITAL pulse width measurement
#define IR_ADC_CHANNEL  2       // ADC channel 2 (GPIO 28)

// Calibration structure for analog mode
typedef struct {
    uint16_t white_val;     // Calibrated white ADC value
    uint16_t black_val;     // Calibrated black ADC value
    uint16_t low_thresh;    // Low threshold for hysteresis
    uint16_t high_thresh;   // High threshold for hysteresis
    uint16_t span;          // Difference between white and black
} ir_calib_t;

// Initialize IR sensor (both analog and digital modes)
void setup_ir_sensor(void);

// ANALOG MODE: Calibrate sensor on white and black surfaces
ir_calib_t calibrate_ir_sensor(void);

// ANALOG MODE: Read raw ADC value with averaging
uint16_t ir_read_analog_raw(uint32_t samples);

// ANALOG MODE: Convert ADC value to voltage (0-3.3V)
float ir_analog_to_voltage(uint16_t adc_val);

// ANALOG MODE: Detect surface with hysteresis (returns true for WHITE, false for BLACK)
bool ir_detect_surface(uint16_t raw_val, bool current_state_white, const ir_calib_t *cal);

// ANALOG MODE: Get contrast percentage (0-100%)
float ir_get_contrast_percent(uint16_t raw_val, const ir_calib_t *cal);

// DIGITAL MODE: Setup GPIO interrupt for pulse width measurement
void setup_ir_digital_irq(void);

// DIGITAL MODE: Get pulse width in milliseconds (returns -1 if no pulse ready)
float ir_get_pulse_width_ms(void);

// DIGITAL MODE: Check if pulse measurement is ready
bool ir_pulse_ready(void);

// DIGITAL MODE: Get current digital GPIO state
bool ir_get_digital_state(void);

#endif