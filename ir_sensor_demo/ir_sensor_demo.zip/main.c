#include "pico/stdlib.h"
#include "functions.h"
#include <stdio.h>

// IRQ variables for pulse width measurement
volatile absolute_time_t pulse_start;
volatile bool pulse_active = false;
volatile float last_pulse_width = 0;
volatile bool pulse_ready = false;

void ir_digital_callback(uint gpio, uint32_t events) {
    absolute_time_t now = get_absolute_time();
    if (events & GPIO_IRQ_EDGE_RISE) {
        pulse_start = now;
        pulse_active = true;
    } else if (events & GPIO_IRQ_EDGE_FALL && pulse_active) {
        last_pulse_width = absolute_time_diff_us(pulse_start, now) / 1000.0f;
        pulse_ready = true;
        pulse_active = false;
    }
}

int main() {
    stdio_init_all();
    
    // Wait for USB connection with timeout
    uint32_t timeout = 0;
    while (!stdio_usb_connected() && timeout < 50) {
        sleep_ms(100);
        timeout++;
    }
    sleep_ms(500);
    
    printf("\n\n");
    printf("========================================\n");
    printf("  WEEK 6 IR SENSOR DEMO\n");
    printf("========================================\n");
    printf("Hardware Setup:\n");
    printf("  ANALOG (AO)  -> GPIO %d (ADC%d)\n", IR_ANALOG_PIN, IR_ADC_CHANNEL);
    printf("  DIGITAL (DO) -> GPIO %d\n", IR_DIGITAL_PIN);
    printf("========================================\n\n");
    
    // Initialize IR sensor
    setup_ir_sensor();
    printf("IR sensor initialized\n\n");
    
    // Setup digital IRQ for pulse width
    gpio_set_irq_enabled_with_callback(IR_DIGITAL_PIN, GPIO_IRQ_EDGE_RISE | GPIO_IRQ_EDGE_FALL, true, &ir_digital_callback);
    
    printf("========================================\n");
    printf("WEEK 6 REQUIREMENTS DEMONSTRATION:\n");
    printf("1. ANALOG (ADC GP28): Surface contrast\n");
    printf("2. DIGITAL (GP7): Pulse width\n");
    printf("========================================\n\n");
    
    // ===== CALIBRATION =====
    printf("=== CALIBRATION ===\n");
    printf("Place sensor over WHITE surface and press Enter...\n");
    while (getchar_timeout_us(0) != PICO_ERROR_TIMEOUT) {} // Flush
    while (getchar_timeout_us(1000000) == PICO_ERROR_TIMEOUT) {} // Wait for input
    
    uint16_t white_raw = ir_read_analog_raw(64);
    float white_voltage = ir_analog_to_voltage(white_raw);
    printf("White: ADC=%u V=%.2f\n\n", white_raw, white_voltage);
    
    printf("Place sensor over BLACK surface and press Enter...\n");
    while (getchar_timeout_us(0) != PICO_ERROR_TIMEOUT) {} // Flush
    while (getchar_timeout_us(1000000) == PICO_ERROR_TIMEOUT) {} // Wait for input
    
    uint16_t black_raw = ir_read_analog_raw(64);
    float black_voltage = ir_analog_to_voltage(black_raw);
    printf("Black: ADC=%u V=%.2f\n\n", black_raw, black_voltage);
    
    // Calculate threshold (midpoint between white and black)
    uint16_t threshold = (white_raw + black_raw) / 2;
    
    // Determine polarity based on actual readings
    // Standard IR sensors: white reflects MORE IR -> HIGHER ADC value
    // So white_raw > black_raw is normal polarity
    bool white_is_higher = (white_raw > black_raw);
    
    printf("Calibrated threshold: %u\n", threshold);
    printf("Polarity: %s\n\n", white_is_higher ? "Normal (White=High)" : "Inverted (White=Low)");
    
    printf("========================================\n");
    printf("STARTING MEASUREMENTS...\n");
    printf("========================================\n\n");
    
    uint32_t pulse_count = 0;
    
    while (true) {
        // ===== PART 1: ANALOG CONTRAST DETECTION =====
        uint16_t raw_val = ir_read_analog_raw(8);
        float voltage = ir_analog_to_voltage(raw_val);
        
        // Determine surface based on calibrated threshold and polarity
        const char *surface;
        if (white_is_higher) {
            // Normal polarity: higher ADC = white
            surface = (raw_val > threshold) ? "WHITE" : "BLACK";
        } else {
            // Inverted polarity: lower ADC = white
            surface = (raw_val < threshold) ? "WHITE" : "BLACK";
        }
        
        // ===== PART 2: DIGITAL PULSE WIDTH =====
        bool digital_state = ir_get_digital_state();
        
        // Print combined output
        printf("ANALOG: ADC=%4u V=%.2f Surface=%s | DIGITAL: GP7=%s", 
               raw_val, voltage, surface, digital_state ? "HIGH" : "LOW ");
        
        // Check if pulse is ready
        if (pulse_ready) {
            pulse_count++;
            printf(" | PULSE#%lu: %.1fms", pulse_count, last_pulse_width);
            pulse_ready = false;
        }
        
        printf("\n");
        
        sleep_ms(200);
    }
    
    return 0;
}