#include "functions.h"
#include "hardware/gpio.h"
#include "hardware/adc.h"
#include <stdio.h>

// Configuration constants
#define SAMPLE_WINDOW   8       // Moving average samples
#define HYST_PCT        6       // Hysteresis percentage (3-10 recommended)

// IRQ variables for digital pulse width measurement
volatile bool irq_measuring = false;
volatile absolute_time_t irq_pulse_start, irq_pulse_end;
volatile bool irq_pulse_ready = false;

// GPIO IRQ handler for digital pulse width measurement
void gpio_irq_handler(uint gpio, uint32_t events) {
    (void)gpio;
    
    // Detect RISING edge (entering HIGH/black)
    if (events & GPIO_IRQ_EDGE_RISE) {
        if (!irq_measuring) {
            irq_pulse_start = get_absolute_time();
            irq_measuring = true;
            irq_pulse_ready = false;
        }
    }
    
    // Detect FALLING edge (leaving HIGH/black)
    if (events & GPIO_IRQ_EDGE_FALL) {
        if (irq_measuring) {
            irq_pulse_end = get_absolute_time();
            irq_measuring = false;
            irq_pulse_ready = true;
        }
    }
}

// Initialize IR sensor
void setup_ir_sensor(void) {
    // Setup ANALOG mode (ADC on GPIO 28)
    adc_init();
    adc_gpio_init(IR_ANALOG_PIN);
    adc_select_input(IR_ADC_CHANNEL);
    
    // Setup DIGITAL mode (GPIO 7)
    gpio_init(IR_DIGITAL_PIN);
    gpio_set_dir(IR_DIGITAL_PIN, GPIO_IN);
    gpio_pull_down(IR_DIGITAL_PIN);
}

// Setup digital IRQ for pulse width measurement
void setup_ir_digital_irq(void) {
    gpio_set_irq_enabled_with_callback(IR_DIGITAL_PIN,
                                      GPIO_IRQ_EDGE_RISE | GPIO_IRQ_EDGE_FALL,
                                      true, &gpio_irq_handler);
    irq_measuring = false;
    irq_pulse_ready = false;
}

// Read ADC with averaging
uint16_t ir_read_analog_raw(uint32_t samples) {
    uint32_t accumulator = 0;
    for (uint32_t i = 0; i < samples; i++) {
        accumulator += adc_read();
        sleep_us(100);
    }
    return (uint16_t)(accumulator / samples);
}

// Convert 12-bit ADC value to voltage (0-3.3V)
float ir_analog_to_voltage(uint16_t adc_val) {
    return (adc_val / 4095.0f) * 3.3f;
}

// Calibrate IR sensor on white and black surfaces
ir_calib_t calibrate_ir_sensor(void) {
    ir_calib_t cal = {0};
    
    printf("\n=== IR SENSOR CALIBRATION (ANALOG MODE) ===\n");
    printf("Place sensor on WHITE surface, then press Enter...\n");
    
    // Wait for Enter (flush buffer first)
    int ch;
    do { ch = getchar_timeout_us(0); } while (ch != PICO_ERROR_TIMEOUT);
    while (true) {
        ch = getchar_timeout_us(100000);
        if (ch == '\n' || ch == '\r') break;
    }
    
    // Read white surface
    printf("Reading white surface via ADC...\n");
    uint16_t white = ir_read_analog_raw(50);
    printf("White ADC: %u (%.2fV)\n\n", white, ir_analog_to_voltage(white));
    
    printf("Place sensor on BLACK surface, then press Enter...\n");
    
    // Wait for Enter
    do { ch = getchar_timeout_us(0); } while (ch != PICO_ERROR_TIMEOUT);
    while (true) {
        ch = getchar_timeout_us(100000);
        if (ch == '\n' || ch == '\r') break;
    }
    
    // Read black surface
    printf("Reading black surface via ADC...\n");
    uint16_t black = ir_read_analog_raw(50);
    printf("Black ADC: %u (%.2fV)\n\n", black, ir_analog_to_voltage(black));
    
    // Ensure white > black
    if (white < black) {
        uint16_t temp = white;
        white = black;
        black = temp;
    }
    
    // Calculate thresholds with hysteresis
    uint16_t span = (white > black) ? (white - black) : 1;
    uint16_t midpoint = black + span / 2;
    uint16_t hyst = (uint16_t)((span * HYST_PCT) / 100);
    if (hyst < 1) hyst = 1;
    
    cal.white_val = white;
    cal.black_val = black;
    cal.span = span;
    cal.low_thresh = midpoint - (hyst / 2);
    cal.high_thresh = midpoint + (hyst / 2);
    
    printf("Calibration complete!\n");
    printf("White: %u, Black: %u, Thresholds: %u/%u\n\n",
           white, black, cal.low_thresh, cal.high_thresh);
    
    return cal;
}

// Detect surface with hysteresis (returns true for WHITE, false for BLACK)
bool ir_detect_surface(uint16_t raw_val, bool current_state_white, const ir_calib_t *cal) {
    if (current_state_white) {
        // Currently on white; switch to black only if below low threshold
        if (raw_val < cal->low_thresh) {
            return false; // Switch to BLACK
        }
    } else {
        // Currently on black; switch to white only if above high threshold
        if (raw_val > cal->high_thresh) {
            return true; // Switch to WHITE
        }
    }
    return current_state_white; // Keep current state
}

// Get contrast percentage (0-100%)
float ir_get_contrast_percent(uint16_t raw_val, const ir_calib_t *cal) {
    if (cal->span == 0) return 0.0f;
    float percent = ((float)(raw_val - cal->black_val) / (float)cal->span) * 100.0f;
    if (percent < 0.0f) percent = 0.0f;
    if (percent > 100.0f) percent = 100.0f;
    return percent;
}

// Get pulse width in milliseconds (returns -1 if no pulse ready)
float ir_get_pulse_width_ms(void) {
    if (!irq_pulse_ready) {
        return -1.0f;
    }
    
    int64_t duration_us = absolute_time_diff_us(irq_pulse_start, irq_pulse_end);
    
    // Reset flag after reading
    irq_pulse_ready = false;
    
    // Filter noise (1ms to 10s range)
    if (duration_us < 1000 || duration_us > 10000000) {
        return -1.0f;
    }
    
    return duration_us / 1000.0f;
}

// Check if pulse measurement is ready
bool ir_pulse_ready(void) {
    return irq_pulse_ready;
}

// Get current digital GPIO state
bool ir_get_digital_state(void) {
    return gpio_get(IR_DIGITAL_PIN);
}